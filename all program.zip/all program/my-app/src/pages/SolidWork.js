const Solidwork = () => (
    <>
      <h1>Solid work</h1>
    </>
)

export default Solidwork