const AutoCad = () => (
    <>
      <h1>Auto cad</h1>
    </>
)

export default AutoCad