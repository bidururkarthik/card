const Catia = () => (
    <>
      <h1>Catia</h1>
    </>
)

export default Catia