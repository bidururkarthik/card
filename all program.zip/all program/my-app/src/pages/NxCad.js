const NxCad = () => (
    <>
      <h1>NxCad</h1>
    </>
)

export default NxCad