const Ansys = () => (
    <>
      <h1>Ansys</h1>
    </>
)

export default Ansys