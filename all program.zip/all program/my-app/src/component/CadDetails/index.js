import { useParams } from 'react-router-dom';

const allProgramCard = [{
  id: 1,
  title: "Auto Cad",
  image: "https:th.bing.com/th?id=OIP.glvBrz5_4H9CGZQnbUHC_QHaEK&w=333&h=187&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2",
  description: "AutoCAD, often abbreviated as CAD is a powerful software tool widely employed in engineering and architecture.",
},
{
  id: 2,
  title: "Solid Works",
  image: "https:th.bing.com/th/id/OIP.AQDpz7xiUf2tZvmi5pvaqAHaD2?w=275&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
  description: "SolidWorks is a 3D parametric design software any other like product you can think of. ",
},

{
  id: 3,
  title: "Catia",
  image: "https:th.bing.com/th/id/OIP.s-pI6dZ3nywiyesZ8U8ajAHaEW?w=292&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
  description: "Manufacturing industries the software to enhance designing, analyzing, and managing new products.",
},

{
  id: 4,
  title: "Nx Cad",
  image: "https:th.bing.com/th/id/OIP.JXvMTe4kGAD9PaqL2CQwiwHaD_?w=296&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
  description: "NX CAD, also known as “unigraphics”, Digital Industries Software",
},

{
  id: 5,
  title: "Ansys",
  image: "https:th.bing.com/th/id/OIP.PRJ-sNHDFySq2HFWmy7RyAHaEn?w=259&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
  description: "Ansys is a CAE/multiphysics engineering simulation software for product design, testing and operation",
},

{
  id: 6,
  title: "Creo",
  image: "https:th.bing.com/th/id/OIP.4wiE3WARi8-J8_VO7HptOgHaEK?w=280&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
  description: "Creo is the 3D CAD solution that helps you accelerate product innovation to build better products faster",
},

{
  id: 7,
  title: "Fusion 360",
  image: "/fusion 360.jpg",
  description: "Fusion 360 offers various 3D design tools that include sketching, direct, surface, parametric, mesh.",
},


{
  id: 8,
  title: "GD&T",
  image: "/gd&t.jpg",
  description: "GD&T symbols used on a drawing to communicate the intent of a design, focusing on the function of the part.",
},

{
  id: 9,
  title: "Inventer",
  image: "/inventer.jpg",
  description: "Inventor 3D CAD software provides professional-grade mechanical design, documentation and product simulation tools.",
},

{
  id: 10,
  title: "Civil 3D",
  image: "/civil 3d.jpg",
  description: "Power your teams’ creativity with the automation, collaboration and machine-learning features Architects, engineers and construction professionals use AutoCAD."
},

{
  id: 11,
  title: "STAAD Pro",
  image: "/staad pro.jpg",
  description: "You can design, analyze, and document structural projects – anywhere in the world, with any material using STAAD. ",
},

{
  id: 12,
  title: "Revit Structure",
  image: "/revit structure.jpg",
  description: "Streamline projects, from design concept to fabrication, with Revit® Building Information Modelling software.",
},

{
  id: 13,
  title: "Etabs",
  image: "/etabs.jpg",
  description: "The ETABS is the ultimate integrated software package for the structural analysis and design of buildings.",
},

{
  id: 14,
  title: "V-rays",
  image: "/v-rays.jpg",
  description: "V-Ray is a rendering engine that uses global illumination, tracing, photon mapping, maps and directly computed global illumination.",
},

{
  id: 15,
  title: "Revit Architecture",
  image: "/revit architecture.jpg",
  description: "Design, detail, analyze, and document structural systems quickly and effectively.",
},

{
  id: 16,
  title: "Photo shop",
  image: "/photo shop.jpg",
  description: "Gorgeous images, rich graphics and incredible art — you can do it all with Photoshop.",
},

{
  id: 17,
  title: "3DS MAX",
  image: "/3d-max.jpg",
  description: "3D modeling, rendering, and animation software enables you to create expansive worlds and premium designs. ",
},

{
  id: 18,
  title: "Lumion",
  image: "/lumion.jpg",
  description: "Product 3D rendering software",
},

{
  id: 19,
  title: "Google Sketchup",
  image: "/google sketchup.jpg",
  description: "The joy of drawing by hand. The ease of super-smart 3D modeling software.",
}

]



const CardDetails = () => {
  const { id } = useParams();
  const selectedProgram = allProgramCard.filter(program => program.id === parseInt(id));
  const {title,description} = selectedProgram[0]
  return(
    <>
      <h1>{title}</h1>
      <p>{description}</p>
    </>
)}

export default CardDetails