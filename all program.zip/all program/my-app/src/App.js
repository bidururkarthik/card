import React from 'react';
import { Component } from 'react';
import { Route } from 'react-router';
import {BrowserRouter as Router,Routes} from 'react-router-dom'
import CardList from './component/CadList'
import AutoCad from './pages/AutoCad'
import Solidwork from './pages/SolidWork'
import Catia from './pages/Catia'
import NxCad from './pages/NxCad'
import Ansys from './pages/Ansys'
import './App.css';




class App extends Component{
      
     
      render(){ 
            return(
            <>
            <Router>
                 <Routes>
                        <Route path="/" element={<CardList/>} />
                        <Route path="/AutoCad" element={<AutoCad/>} />
                        <Route path="/Solidwork" element={<Solidwork/>} />
                        <Route path="/Catia" element={<Catia/>} />
                        <Route path="/Ansys" element={<Ansys/>} />
                        <Route path="/NxCad" element={<NxCad/>} />
                  </Routes>
            </Router>
            </>
      )}
}
export default App
